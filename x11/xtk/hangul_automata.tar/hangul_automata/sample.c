/*
*  X/Motif Text Widget�� �ѱ� ���丶Ÿ�� 
*   ������ Sample ���α׷��Դϴ�. 
*
*   Programed By Kim Bum Chul 95.11.28
*/

#include <locale.h>
#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/PushB.h>
#include "han_callback.h"

/*
#define   FONTLIST   "clb8x16,tg16"
*/

XtAppContext app;

/* �ѱ� ���丶Ÿ�� ���� �������� */
  
static int             han_mode = ON;
static int             cur_state = 1;
static char            cur_key = 0;
static unsigned short  cur_wansung = 0x8000;
static unsigned short  old_wansung = 0x8000;

void toggle_han_mode();
void modifyVerify_cb(); /* XmNmodifyVerifyCallback �Լ� */
void focus_bumchul(), activate_bumchul(), reset_han_mode();
extern  int     han_automata(); /* �ѱۿ��丶Ÿ */

/* ��/�� toggle�� ���� Translations ���� */
static char     defaultTranslations[] = 
"\
<Btn3Down>:toggle_han_mode()";
/* ���� shift-space�� �ٲٰ� �ʹٸ� 
Shift <KeyPress> space:toggle_han_mode()";
*/

static  XtActionsRec appActions[] =
{
        { "toggle_han_mode",toggle_han_mode},
};

void goodbye (w, client_data, call_data)
 Widget     w;
 XtPointer  client_data;
 XtPointer  call_data;
{
    printf("Exited. \n");
    exit(0);
}


void main(argc, argv)
unsigned  int argc;
char      *argv[];
{

    int      n;
    XtTranslations  trans_table;
/*
    int      missing_charset_count;
    char     **missing_charset_list, *def_string;
    XFontSet fontset;
    XmFontList  fontlist;
    XmFontListEntry  flentry;
*/
    Arg      myArgs[5];
    Widget   toplevel, main_form;
    Widget   label, text, pbutton;

/* �������� ����, �ݵ�� �ʿ��ϴ� */
    setlocale(LC_CTYPE, "");

    toplevel = XtVaAppInitialize(&app, "Sample", NULL, 0, &argc, argv,
				NULL,NULL);

    n = 0;
    XtSetArg(myArgs[n], XmNwidth,300 ); n++;
    XtSetArg(myArgs[n], XmNheight,100 ); n++;
    main_form = XmCreateForm(toplevel, "main_form", myArgs, n);
    XtManageChild(main_form);


    /*  ��Ʈ���� ����  */
/*
    fontset  = XCreateFontSet(XtDisplay(toplevel), FONTLIST, &missing_charset_list,
                                              &missing_charset_count, &def_string);
    flentry  = XmFontListEntryCreate("koreanEUC", XmFONT_IS_FONTSET, fontset);
    fontlist = XmFontListAppendEntry((XmFontList) NULL, flentry);
*/


    n = 0;
    XtSetArg (myArgs[n], XmNx, 22); n++;
    XtSetArg (myArgs[n], XmNy, 20); n++ ;
/*
    XtSetArg (myArgs[n], XmNfontList, fontlist); n++ ;
*/
    XtSetArg (myArgs[n], XmNlabelString, XmStringCreate(" �ﺸ ����ũ�νý��� R&D GUI��",
    "koreanEUC")); n++;
    label = XmCreateLabel(main_form, "label", myArgs, n);
    XtManageChild(label);

    XtAppAddActions(app,appActions, XtNumber(appActions));

    n = 0;
    XtSetArg(myArgs[n], XmNx, 30); n++;
    XtSetArg(myArgs[n], XmNy, 45); n++;
    XtSetArg(myArgs[n], XmNwidth, 170); n++;
    XtSetArg(myArgs[n], XmNverifyBell,   False); n++;
    text = XmCreateText(main_form, "text", myArgs, n);
    XtManageChild(text);
/* XmNmodifyVerifyCallback�� ����Ѵ� */ 
    XtAddCallback(text, XmNmodifyVerifyCallback, modifyVerify_cb, NULL);
    XtAddCallback(text, XmNfocusCallback, focus_bumchul, NULL);
    XtAddCallback(text, XmNactivateCallback, activate_bumchul, NULL);

    trans_table = XtParseTranslationTable(defaultTranslations);
    XtOverrideTranslations(text,trans_table);

    n = 0;
    XtSetArg(myArgs[n], XmNx, 210); n++;
    XtSetArg(myArgs[n], XmNy, 48); n++;
/*
    XtSetArg (myArgs[n], XmNfontList, fontlist); n++ ;
*/
    XtSetArg(myArgs[n], XmNlabelString, XmStringCreate("�� ħ","koreanEUC")); n++;
    pbutton = XmCreatePushButton(main_form, "pbutton", myArgs, n);
    XtAddCallback(pbutton, XmNactivateCallback, goodbye, NULL);
    XtManageChild(pbutton);


    XtRealizeWidget(toplevel);
    XtAppMainLoop(app);
}

/*
*  XmNmodifyVerifyCallback�� �߻����� ��� �Էµ� string�� �ѱ��� toggle �� 
*  ���¶�� ���丶Ÿ�� ���� �ϼ��� �ѱ� �ڵ带 �����Ͽ� �Էµ� string�� �ϼ��� 
*  �ѱ� �ڵ�� replace��Ų��.
*
*   Programed By Kim Bum Chul 95.11.28
*/
void
modifyVerify_cb(widget, unused, cbs)
	Widget				widget;
	XtPointer			unused;
	XmTextVerifyCallbackStruct	*cbs;
{
	int		r;
	XmTextPosition	cursor_pos;
	char		cw[3], ow[3];

	if (han_mode == OFF) {
		reset_han_mode();
		return;
	}

	if (cbs -> text -> length != 1) {
		reset_han_mode();
		return;
	}
	if (! cbs -> text -> ptr) {
		reset_han_mode();
		return;
	}
	if (! isalpha(cbs -> text -> ptr[0])) {
		reset_han_mode();
		return;
	}

	cur_key = cbs -> text -> ptr[0];
	r = han_automata(cur_key, &cur_state, &cur_wansung, &old_wansung);
	printf("code : %x\n", cur_wansung);
	cw[0] = (cur_wansung & 0xff00) >> 8;
	cw[1] = (cur_wansung & 0x00ff);
	cw[2] = '\0';
	ow[0] = (old_wansung & 0xff00) >> 8;
	ow[1] = (old_wansung & 0x00ff);
	ow[2] = '\0';
	switch (r) {
		case -2:
			cbs -> text -> length = 2;
			XtRealloc(cbs -> text -> ptr, 2);
			cbs -> text -> ptr[0] = cw[0];
			cbs -> text -> ptr[1] = cw[1];
			cbs -> text -> format = FMT16BIT;
			break;
		case 0:
			cursor_pos = XmTextGetCursorPosition(widget);
			XtRemoveCallback(widget, XmNmodifyVerifyCallback, modifyVerify_cb, NULL);
			XmTextReplace(widget, cursor_pos-1, cursor_pos, cw);
			XtAddCallback(widget, XmNmodifyVerifyCallback, modifyVerify_cb, NULL);
			cbs -> doit = False;
			break;
		case 2:
			cursor_pos = XmTextGetCursorPosition(widget);
			XtRemoveCallback(widget, XmNmodifyVerifyCallback, modifyVerify_cb, NULL);
			XmTextReplace(widget, cursor_pos-1, cursor_pos, ow);
			XtAddCallback(widget, XmNmodifyVerifyCallback, modifyVerify_cb, NULL);
			cbs -> text -> length = 2;
			XtRealloc(cbs -> text -> ptr, 2);
			cbs -> text -> ptr[0] = cw[0];
			cbs -> text -> ptr[1] = cw[1];
			cbs -> text -> format = FMT16BIT;
			break;
		default:
			break;
	}
}

void
focus_bumchul(widget, unused, cbs)
	Widget				widget;
	XtPointer			unused;
	XmTextVerifyCallbackStruct	*cbs;
{
	if (han_mode == ON) {
		reset_han_mode();
	}
}

void
motionVerify_cb(widget, unused, cbs)
	Widget				widget;
	XtPointer			unused;
	XmTextVerifyCallbackStruct	*cbs;
{

}

void
activate_bumchul(widget, unused, cbs)
	Widget				widget;
	XtPointer			unused;
	XmAnyCallbackStruct		*cbs;
{
	printf("text : %s\n",XmTextGetString(widget));
}


void
toggle_han_mode()
{
	han_mode = ((han_mode == ON) ? (OFF) : (ON));
	reset_han_mode();
}

void
reset_han_mode()
{
	cur_state = 1;
	cur_wansung = 0x8000;
	cur_key = 0;
	old_wansung = 0x8000;
}
